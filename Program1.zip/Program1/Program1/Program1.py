import sqlite3
import random
#import schedule
import time
import os
import csv
import logging
import tkinter as tk
from tkinter import simpledialog, messagebox
import shutil
from types import NoneType
from threading import Lock

#Configure logging
#logging.basicConfig(filename='app.log', filemode='a', format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)

#Function to validate and assign INVALID to None or invalid values
def validate_data(value):
    if value is None or not isinstance(value, (int, float)):
        return "INVALID"
    return value

#Setup database
def setup_database(db_path):
    attempt = 0;
    #while attempt < 3:
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS data ( 
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            grid_kw TEXT,
            grid_amps TEXT,
            grid_frequency TEXT
            )
        ''')
        conn.commit()
        conn.close()
        print("Database setup complete")
        #logging.info("Database setup complete")
        #return
    except Exception as e:
        attempt += 1
        #logging.error(f"Attempt {attempt}: An error occurred during database setup: {e}")
        print(f"An error occurred during database setup: {e}")
        time.sleep(1)
    #print("Failed to set up database after multiple attempts")

#Function to read data
def read_data():
    try:
          grid_kw = random.uniform(0, 100)
          grid_amps = random.uniform(0, 100)
          grid_frequency = random.uniform(0, 100)

          grid_kw = validate_data(grid_kw)
          grid_amps = validate_data(grid_amps)
          grid_frequency = validate_data(grid_frequency)

          return grid_kw, grid_amps, grid_frequency
    except Exception as e:
          print(f"An error occurred whilst reading the data: {e}")
          return "INVALID", "INVALID", "INVALID"

#Path to DDL file
ddl_file_lock = Lock()
ddl_file_path = r'C:\Users\Marcl\Desktop\TKS werk\Program1\Program1\data_ddl.sql'

#Function to store data
def store_data(db_path, grid_kw, grid_amps, grid_frequency):
    attempt = 0
    #while attempt < 3:
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO data (grid_kw, grid_amps, grid_frequency) VALUES (?, ?, ?)
        ''', (grid_kw, grid_amps, grid_frequency))
        conn.commit()

        #Retrive the inserted row to get id and timestamp
        cursor.execute('''
            SELECT id, timestamp FROM data WHERE id = last_insert_rowid()
        ''')
        row = cursor.fetchone()
        id, timestamp = row[0], row[1]

        conn.close()
        print(f"Data stored: grid_kw = {grid_kw}, grid_amps = {grid_amps}, grid_frequency = {grid_frequency}")
        
        #Append to DDL file
        with ddl_file_lock:
            append_to_ddl(ddl_file_path, id, timestamp, grid_kw, grid_amps, grid_frequency)
        return
    except Exception as e:
        attempt += 1
        print(f"An error occurred during data storage: {e}")
        time.sleep(1)
    #print("Failed to store data after multiple attempts")

#Function to append data to DDL file
def append_to_ddl(ddl_file_path, id, timestamp, grid_kw, grid_amps, grid_frequency):
    try:
        with open(ddl_file_path, 'a') as ddl_file:
            ddl_file.write(f"{id},{timestamp},{grid_kw},{grid_amps},{grid_frequency}\n")
    except Exception as e:
        print(f"AN error occurred while appending to DDL file: {e}")

#Scheduled job
#def job():
#    value = read_data()
#    store_data(value)
#    print(f'Data stored: {value}')

#Main script
#db_path = os.path.join(os.getcwd(), 'data.db')
db_path = r'C:\Users\Marcl\Desktop\TKS werk\Program1\Program1\data.db'
setup_database(db_path)
#schedule.every(1).minute.do(job)


#while True:
for _ in range(5):
    grid_kw, grid_amps, grid_frequency = read_data()
    if grid_kw is not None and grid_amps is not None and grid_frequency is not None:
        store_data(db_path, grid_kw, grid_amps, grid_frequency)
    else:
        print("Skipping data storage due to read error")
        #print(f'Data stored: {value}')
        #schedule.run_pending()
    time.sleep(5)

def export_to_ddl(database_path, ddl_file_path):
    attempt = 0
    #while attempt < 3:
    try:
        #Connect to SQLite database
        conn = sqlite3.connect(database_path)
        cursor = conn.cursor()

        """
        #Get table schema(DDL)
        cursor.execute("SELECT sql from sqlite_master WHERE type='table' AND name ='data';")
        table_schema = cursor.fetchone()[0]
        """

        #Get table data
        cursor.execute("SELECT * FROM data;")
        rows = cursor.fetchall()

        
        #Get column names
        cursor.execute("PRAGMA table_info(data);")
        columns = [column[1] for column in cursor.fetchall()]
        
        
        #Open the DDL file for writing
        with open(ddl_file_path, 'w') as ddl_file:
            #Write table schema
            #ddl_file.write(f"{table_schema};\n\n")

            #Write the data as INSERT statements
            for row in rows:
                values = ', '.join([f"'{value}'" if isinstance(value, str) else str(value) for value in row])
                ddl_file.write(f"{row[0]},{row[1]},{row[2]},{row[3]},{row[4]}\n")
                #ddl_file.write(f"INSERT INTO data({', '.join(columns)}) VALUES ({values});\n")
                #ddl_file.write(f"({', '.join(columns)}) VALUES ({values});\n")
        
        """
        # Open the CSV file for writing
        with open(csv_file_path, 'w', newline='') as csv_file:
            writer = csv.writer(csv_file)
            
            # Write column headers
            writer.writerow(['id', 'timestamp', 'grid_kw', 'grid_amps', 'grid_frequency'])
            
            # Write the data
            for row in rows:
                writer.writerow(row)

        #Close database connection
        conn.close()
        """ 
        print(f"DDL file created successfully at {ddl_file_path}")
        messagebox.showinfo("Data exported to DDL file successfully")
    except Exception as e:
        attempt += 1
        print(f"An error occurred during DDL export: {e}")
        time.sleep(1)
    #print("Failed to export DDL after multiple attempts")
   
#Function to detect USB drive
def detect_usb_drive():
    usb_path = None
    possible_paths = [r'E:']

    for path in possible_paths:
        if os.path.exists(path):
            usb_path = path
            break
    return usb_path

#Function to export data to USB drive
def export_to_usb():
    usb_drive_path = detect_usb_drive()
    if usb_drive_path:
        usb_file_path = os.path.join(usb_drive_path, 'data_ddl.sql')
        with ddl_file_lock:
        #export_to_ddl(db_path, ddl_file_path)
            shutil.copy(ddl_file_path, usb_file_path)
        print(f"Data exported to USB drive at {usb_file_path}")
        messagebox.showinfo("Data exported to USB successfully")
    else:
        print("No USB drive detected")

#csv_file_path = r'C:\Users\Marcl\Desktop\TKS werk\TestImport\TestImport\data.csv'
#export_to_csv(db_path, csv_file_path)

#Authorise
def delete_data():
    password = simpledialog.askstring("Password", "Enter password: ", show='*')
    if password == '12345':
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute('DELETE FROM data')
            conn.commit()
            conn.close()
            with ddl_file_lock:
                if os.path.exists(ddl_file_path):
                    os.remove(ddl_file_path)
            messagebox.showinfo("Success", "All data has been deleted")
            print(f"Data deleted successfully")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    else:
        messagebox.showerror("Error", "Incorrect password")

#GUI#

#Function to update the GUI labels
def update_labels():
    grid_kw, grid_amps, grid_frequency = read_data()
    if grid_kw is not None and grid_amps is not None and grid_frequency is not None:
        store_data(db_path, grid_kw, grid_amps, grid_frequency)
        kw_label1.config(text=f"{grid_kw}")
        amps_label1.config(text=f"{grid_amps}")
        f_label1.config(text=f"{grid_frequency}")
    else:
        print("Skipping data storage due to read error")
    root.after(5000, update_labels)

#Create window
root = tk.Tk()

#Modify root window
root.title("GUI")
root.geometry("7000x7000")
root.configure(background="darkblue")

#Create a frame to hold labels and buttons
main_frame = tk.Frame(root, bd=2, relief="solid", padx=10, pady=10, highlightbackground="white", highlightthickness=2, bg="red")
main_frame.place(relx=0.5,rely=0.5, anchor="center")

#Create label
kw_label = tk.Label(main_frame, text = "Grid kW: ", bg="red", font=("Arial", 14, "bold"))
kw_label.grid(row=0, column=0, padx = 10, pady = 10, sticky='e')

amps_label = tk.Label(main_frame, text = "Grid Amps: ", bg="red", font=("Arial", 14, "bold"))
amps_label.grid(row=1, column=0, padx = 10, pady = 10, sticky='e')

f_label = tk.Label(main_frame, text = "Grid Frequency: ", bg="red", font=("Arial", 14, "bold"))
f_label.grid(row=2, column=0, padx = 10, pady = 10, sticky='e')

kw_label1 = tk.Label(main_frame, text = '{grid_kw}', bg="red", font=("Arial", 14, "bold"))
kw_label1.grid(row=0, column=1, padx = 10, pady = 10, sticky='w')

amps_label1 = tk.Label(main_frame, text = '{grid_amps}', bg="red", font=("Arial", 14, "bold"))
amps_label1.grid(row=1, column=1, padx = 10, pady = 10, sticky='w')

f_label1 = tk.Label(main_frame, text = '{grid_frequency}', bg="red", font=("Arial", 14, "bold"))
f_label1.grid(row=2, column=1, padx = 10, pady = 10, sticky='w')

#Create button
button1 = tk.Button(main_frame, text = "Export", command=export_to_usb, width=15, height=2, bg="dark blue", fg="white", font=("Arial", 14,"bold"))
button1.grid(row=3, column=1, columnspan=2, pady=20, padx=0, sticky='e')

button2 = tk.Button(main_frame, text="Delete Data", command=delete_data, width=15, height=2, bg="dark blue", fg="white", font=("Arial", 14, "bold"))
button2.grid(row=3, column=3, padx=10, pady=20, sticky='w')

"""
buttonframe = tk.Frame(root)
buttonframe.columnconfigure(0, weight=1)
buttonframe.columnconfigure(1, weight=1)
buttonframe.columnconfigure(2, weight=1)
"""
#Start updating the labels
update_labels()

#Event loop
root.mainloop()


export_to_ddl(db_path, ddl_file_path)

"""
btn1 = tk.Button(buttonframe, text="1", font=('Arial',18))
btn1.grid(row=0, column=0, sticky=tk.W+tk.E)

buttonframe.pack(fill='x')

btn2 = tk.Button(root, text = "Test")
btn2.place(x=200, y=200, height = 100, width = 100)
"""
"""

grid1 = tk
#Event loop
root.mainloop()



def button_clicked():
    print("Button clicked!")

"""
"""
#Creating a button with specified options
button = tk.Button(root, 
                   text="Click Me", 
                   command=button_clicked,
                   activebackground="blue", 
                   activeforeground="white",
                   anchor="center",
                   bd=3,
                   bg="lightgray",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Arial", 12),
                   height=2,
                   highlightbackground="black",
                   highlightcolor="green",
                   highlightthickness=2,
                   justify="center",
                   overrelief="raised",
                   padx=10,
                   pady=5,
                   width=15,
                   wraplength=100)


button.pack(padx=20, pady=20)

"""



